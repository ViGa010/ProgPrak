import GUI.Frame;

public class Main {

	public static final int BOX = 32;
	public static final int WIDTH = 16, HEIGHT = 16;
	
	
	
   public static void main (String[] args) {

	   
	   
	  new Frame(BOX*WIDTH, BOX*HEIGHT);
	   
   }
 
}