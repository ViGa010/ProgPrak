package datenstruktur;

public class Monster {

}
