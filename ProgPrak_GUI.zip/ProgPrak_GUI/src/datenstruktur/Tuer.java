package datenstruktur;

public class Tuer {

}
