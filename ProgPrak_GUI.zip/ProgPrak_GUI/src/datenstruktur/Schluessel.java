package datenstruktur;

public class Schluessel {

}
