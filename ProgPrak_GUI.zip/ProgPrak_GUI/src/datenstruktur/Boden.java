package datenstruktur;

public class Boden {

}
