package datenstruktur;

public class Heiltrank {

}
