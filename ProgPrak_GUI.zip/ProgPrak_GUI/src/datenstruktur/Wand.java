package datenstruktur;

public class Wand {

}
